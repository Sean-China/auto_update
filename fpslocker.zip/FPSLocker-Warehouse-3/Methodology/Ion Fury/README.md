# Ion Fury

> Game info

TitleID: `010041C00D086000`<br>
Explanation based on:
- Internal version: `1.07.1`, 
- Nintendo version ID: `v4`/`v262144`
- BID: `9D2EFCF198F2247F`
- Engine: `Build`

> Details

Game is using internal FPS lock. To unlock it do wherever you want a Konami Code, which is a button combo that looks like this (arrows represent D-Pad):
```
⬆️⬆️⬇️⬇️⬅️➡️⬅️➡️🅱️🅰️
```