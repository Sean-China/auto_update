# Ultra Kaiju Monster Rancher

> Game info

TitleID: `01008E0019388000`<br>
Explanation based on:
- Internal version: `1.0.1`, 
- Nintendo version ID: `v0`
- BID: `53384CC3D2B4CA9F`
- Engine: proprietary

> Details

Plugin can set FPS above 30 alone, but game speed is tied to framerate, so it is required to patch it.