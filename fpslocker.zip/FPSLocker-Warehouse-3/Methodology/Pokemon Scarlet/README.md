# Pokemon Scarlet

> Game info

TitleID: `0100A3D008C5C000`<br>
Explanation based on:
- Internal version: `1.3.0`, 
- Nintendo version ID: `v4`/`v262144`
- BID: `6EE2D5E3216EBDA5`
- Engine: proprietary

> Details

Game can be unlocked to 60 FPS with plugin alone, but because game speed is tied to framerate, we need to patch it. After applying game speed cheat character model is jumping between where it should be and where is it, causing stuttering. This game requires more work to do than just unlocking FPS and setting game speed.
