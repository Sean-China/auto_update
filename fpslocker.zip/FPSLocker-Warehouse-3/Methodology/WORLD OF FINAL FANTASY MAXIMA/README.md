# WORLD OF FINAL FANTASY MAXIMA

> Game info

TitleID: `010072000BD32000`<br>
Explanation based on:
- Internal version: `1.0.1`, 
- Nintendo version ID: `v1`/`v65536`
- BID: `5767FD44C331B44B`
- Engine: proprietary

> Details

Plugin can set FPS above 30 alone, but some cutscenes are tied to framerate, so at 60 FPS they are 2x faster. And other cutscenes that are not tied to framerate have lipsync adjustments tied to framerate, so lips movement is broken.