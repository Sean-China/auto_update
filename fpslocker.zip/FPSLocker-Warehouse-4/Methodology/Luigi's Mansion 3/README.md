# Luigi's Mansion 3

> Game info

TitleID: `0100DCA0064A6000`<br>
Explanation based on:
- Internal version: `1.4.0`, 
- Nintendo version ID: `v5`/`v327680`
- BID: `79E5950FFA85ACF6`
- Engine: Next Level Games proprietary engine

> Details

SaltyNX doesn't support this game because game doesn't want to give even a bit of free space for plugins. For 60 FPS read [THIS](https://gbatemp.net/threads/luigis-mansion-3-60fps-mod.557992/)
