# Bang-On Balls: Chronicles

> Game info

TitleID: `010081E01A45C000`<br>
Explanation based on:
- Internal version: `1.0.1`, 
- Nintendo version ID: `v1`/`v65536`
- BID: `6B5E31BAA58DB229`
- Engine: `Unreal Engine 4`

> Details 

Plugin allows 60FPS to be set, however performance is subpar as dynamic resolution is set to 33.33ms and VSync is enabled. An additional patch allows these issues to be fixed.
