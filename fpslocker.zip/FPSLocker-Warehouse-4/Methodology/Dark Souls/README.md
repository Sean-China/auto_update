# Dark Souls Remastered

> Game info

TitleID: `01004AB00A260000`<br>
Explanation based on:
- Internal version: `1.0.3`, 
- Nintendo version ID: `v3/v196608`
- BID: `DF3766A2BB651A3E`
- Engine: `Katana`

> Details

Game is using internal FPS lock that is also used to tie game speed to framerate. So when FPS drops, game slows down.
Above 30 FPS patch locks itself to 30 FPS when using ladders because otherwise there is a chance that you can fall down through ground when exiting ladder sequence.
