# The Legend of Heroes: Trails of Cold Steel III

> Game info

TitleID: `01005420101DA000`<br>
Explanation based on:
- Internal version: `1.0.1`, 
- Nintendo version ID: `v1`/`v65536`
- BID: `134EC3D8BE75126F`
- Engine: Heavily modified `Phyre` engine

> Details

Game is using internal FPS locker which value is hardcoded into executable. It cannot be patched with FPSLocker.
To enable 60 FPS use [THIS](https://gbatemp.net/threads/trails-of-cold-steel-3-configuration-menu.583383/) tool.