# TY the Tasmanian Tiger 2

> Game info

TitleID: `0100BC701417A000`<br>
Explanation based on:
- Internal version: `1.0.1`, 
- Nintendo version ID: `v1`/`v65536`
- BID: `1F8808E4FC7516D2`
- Engine: modified Super Mario Sunshine engine

> Details

Game can be unlocked to 60 FPS with plugin alone, but because of using double buffer setting anything between 30 and 60 causes framerate to be unstable.